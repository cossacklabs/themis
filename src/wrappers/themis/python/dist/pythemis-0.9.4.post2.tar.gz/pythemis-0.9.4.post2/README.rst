themis
=====
Themis is a data security library, providing users with high-quality 
security services for secure messaging of any kinds and flexible data 
storage. Themis is aimed at modern developers, with high level OOP 
wrappers for Ruby, Python, PHP, Java / Android and iOS / OSX. It is d
esigned with ease of use in mind, high security and cross-platform 
availability.